#!/bin/sh
cd /mnt/apps/SimpleMenu
./simplemenu
